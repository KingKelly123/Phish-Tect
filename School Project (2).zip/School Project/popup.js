// Function to update the stats display
function updateStats() {
  chrome.runtime.sendMessage({ type: 'GET_STATS' }, function(response) {
    const stats = response.stats;
    const lastDetection = response.lastDetection;
    
    // Update stats numbers
    document.getElementById('blockedCount').textContent = stats.blocked;
    document.getElementById('warningsCount').textContent = stats.warnings;
    document.getElementById('falsePositivesCount').textContent = stats.falsePositives;
    
    // Update last detection
    const lastDetectionElement = document.getElementById('lastDetection');
    if (lastDetection) {
      const detectionTime = new Date(lastDetection.time);
      const formattedTime = detectionTime.toLocaleString();
      lastDetectionElement.innerHTML = `
        <div class="detection-item">
          <strong>URL:</strong> ${lastDetection.url}<br>
          <strong>Time:</strong> ${formattedTime}<br>
          <strong>Type:</strong> ${lastDetection.type}
        </div>
      `;
    } else {
      lastDetectionElement.innerHTML = '<div class="no-detections">No recent detections</div>';
    }
  });
}

// Function to check current URL
function checkCurrentURL() {
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    const currentUrl = tabs[0].url;
    chrome.runtime.sendMessage({ type: 'CHECK_URL', url: currentUrl }, function(response) {
      const statusElement = document.getElementById('currentStatus');
      if (response.isSuspicious) {
        statusElement.innerHTML = `
          <div class="warning">
            <strong>Warning:</strong> This URL appears suspicious!
            <button id="reportFalsePositive" class="report-button">Report False Positive</button>
          </div>
        `;
        
        // Add event listener to the report button
        document.getElementById('reportFalsePositive').addEventListener('click', function() {
          chrome.runtime.sendMessage({ 
            type: 'REPORT_FALSE_POSITIVE', 
            url: currentUrl 
          }, function(response) {
            if (response.success) {
              statusElement.innerHTML = '<div class="success">Reported as false positive. Thank you!</div>';
              updateStats();
            }
          });
        });
      } else {
        statusElement.innerHTML = '<div class="safe">This URL appears safe.</div>';
      }
    });
  });
}

// Initialize popup
document.addEventListener('DOMContentLoaded', function() {
  // Update stats and check current URL when popup opens
  updateStats();
  checkCurrentURL();
  
  // Add event listener to the refresh button
  document.getElementById('refreshButton').addEventListener('click', function() {
    updateStats();
    checkCurrentURL();
  });
});

// Listen for real-time stats updates
chrome.storage.onChanged.addListener(function(changes, area) {
  if (area === 'local' && changes.stats) {
    updateStats();
  }
}); 