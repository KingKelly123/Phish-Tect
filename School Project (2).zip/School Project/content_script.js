// Function to check for suspicious content
function checkForSuspiciousContent() {
  const suspiciousElements = [];
  
  // Check for suspicious forms
  const forms = document.getElementsByTagName('form');
  for (const form of forms) {
    const formText = form.innerHTML.toLowerCase();
    if (formText.includes('password') || 
        formText.includes('login') ||
        formText.includes('account') ||
        formText.includes('verify') ||
        formText.includes('secure')) {
      suspiciousElements.push({
        type: 'form',
        element: form,
        reason: 'Contains sensitive form fields'
      });
    }
  }
  
  // Check for suspicious links
  const links = document.getElementsByTagName('a');
  for (const link of links) {
    const href = link.getAttribute('href');
    if (href) {
      const hrefLower = href.toLowerCase();
      if (hrefLower.includes('login') || 
          hrefLower.includes('password') || 
          hrefLower.includes('account') ||
          hrefLower.includes('verify') ||
          hrefLower.includes('secure')) {
        suspiciousElements.push({
          type: 'link',
          element: link,
          reason: 'Contains suspicious URL'
        });
      }
    }
  }
  
  // Check for suspicious text content
  const suspiciousKeywords = ['password', 'login', 'account', 'verify', 'secure', 'bank', 'paypal'];
  const textNodes = document.evaluate(
    '//text()[not(ancestor::script) and not(ancestor::style)]',
    document.body,
    null,
    XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE,
    null
  );
  
  for (let i = 0; i < textNodes.snapshotLength; i++) {
    const node = textNodes.snapshotItem(i);
    const text = node.textContent.toLowerCase();
    for (const keyword of suspiciousKeywords) {
      if (text.includes(keyword)) {
        const parent = node.parentElement;
        if (parent && !suspiciousElements.some(el => el.element === parent)) {
          suspiciousElements.push({
            type: 'text',
            element: parent,
            reason: `Contains suspicious keyword: ${keyword}`
          });
        }
      }
    }
  }
  
  return suspiciousElements;
}

// Function to highlight suspicious elements
function highlightSuspiciousElements(elements) {
  elements.forEach(item => {
    const element = item.element;
    element.style.border = '2px solid red';
    element.style.padding = '5px';
    element.style.position = 'relative';
    
    // Add tooltip
    const tooltip = document.createElement('div');
    tooltip.style.position = 'absolute';
    tooltip.style.backgroundColor = 'red';
    tooltip.style.color = 'white';
    tooltip.style.padding = '5px';
    tooltip.style.borderRadius = '3px';
    tooltip.style.fontSize = '12px';
    tooltip.style.zIndex = '1000';
    tooltip.style.top = '-25px';
    tooltip.style.left = '0';
    tooltip.textContent = item.reason;
    element.appendChild(tooltip);
  });
}

// Main content analysis
function analyzeContent() {
  chrome.storage.local.get(['highlightElements'], function(data) {
    if (data.highlightElements !== false) {
      const suspiciousElements = checkForSuspiciousContent();
      
      if (suspiciousElements.length > 0) {
        highlightSuspiciousElements(suspiciousElements);
        
        // Send message to background script
        chrome.runtime.sendMessage({
          type: 'SUSPICIOUS_CONTENT',
          count: suspiciousElements.length,
          url: window.location.href
        });
      }
    }
  });
}

// Run analysis when page loads
document.addEventListener('DOMContentLoaded', analyzeContent);

// Run analysis when page content changes
const observer = new MutationObserver(analyzeContent);
observer.observe(document.body, {
  childList: true,
  subtree: true
}); 