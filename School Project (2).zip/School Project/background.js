// List of known phishing indicators
const phishingIndicators = {
  keywords: [
    'login',
    'password',
    'account',
    'verify',
    'secure',
    'bank',
    'paypal',
    'amazon',
    'ebay',
    'microsoft',
    'apple',
    'google'
  ],
  suspiciousPatterns: [
    /https?:\/\/([a-z0-9]+\.)?([a-z0-9]+\.)?([a-z0-9]+\.)?(login|account|verify|secure)\./i,
    /https?:\/\/([a-z0-9]+\.)?([a-z0-9]+\.)?([a-z0-9]+\.)?(bank|paypal|amazon|ebay)\./i
  ]
};

// Load test links from JSON file
let testWebsites = { safe: [], phishing: [] };

// Function to load test links
async function loadTestLinks() {
  try {
    const response = await fetch(chrome.runtime.getURL('test-links.json'));
    testWebsites = await response.json();
    console.log('Test links loaded successfully');
    // Update rules after loading test links
    updateRules();
  } catch (error) {
    console.error('Error loading test links:', error);
  }
}

// Function to create rules from test links
async function updateRules() {
  const rules = [];
  let ruleId = 1;

  // Add rules for phishing URLs
  for (const site of testWebsites.phishing) {
    rules.push({
      id: ruleId++,
      priority: 1,
      action: {
        type: 'redirect',
        redirect: {
          extensionPath: '/blocked.html?url=' + encodeURIComponent('http://' + site.url)
        }
      },
      condition: {
        urlFilter: site.url,
        resourceTypes: ['main_frame']
      }
    });
  }

  // Add rules for typosquatting patterns
  const typosquattingPatterns = [
    { original: 'google', fake: 'g00gle' },
    { original: 'facebook', fake: 'faceb00k' },
    { original: 'amazon', fake: 'amaz0n' },
    { original: 'paypal', fake: 'paypa1' },
    { original: 'microsoft', fake: 'm1crosoft' },
    { original: 'github', fake: 'g1thub' },
    { original: 'twitter', fake: 'tw1tter' },
    { original: 'instagram', fake: 'insta1gram' },
    { original: 'linkedin', fake: 'link3din' },
    { original: 'youtube', fake: 'youtu1be' },
    { original: 'tiktok', fake: 'tikt0k' },
    { original: 'snapchat', fake: 'snapch4t' },
    { original: 'pinterest', fake: 'pin1ster' },
    { original: 'reddit', fake: 'redd1t' },
    { original: 'ebay', fake: 'ebay1' },
    { original: 'walmart', fake: 'walmart1' },
    { original: 'target', fake: 'targ3t' },
    { original: 'apple', fake: 'appl3' },
    { original: 'microsoft', fake: 'm1crosoft' }
    
    
  ];

  for (const pattern of typosquattingPatterns) {
    rules.push({
      id: ruleId++,
      priority: 1,
      action: {
        type: 'redirect',
        redirect: {
          extensionPath: '/blocked.html?url=' + encodeURIComponent('http://' + pattern.fake + '.com')
        }
      },
      condition: {
        urlFilter: pattern.fake,
        resourceTypes: ['main_frame']
      }
    });
  }

  // Update rules
  try {
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: rules.map(rule => rule.id),
      addRules: rules
    });
    console.log('Rules updated successfully');
  } catch (error) {
    console.error('Error updating rules:', error);
  }
}

// Function to check if URL is suspicious
function isSuspiciousURL(url) {
  try {
    const urlObj = new URL(url);
    const hostname = urlObj.hostname.toLowerCase();
    
    // Check against our test phishing list
    const phishingMatch = testWebsites.phishing.find(phish => hostname.includes(phish.url));
    if (phishingMatch) {
      console.log('URL matched phishing list:', phishingMatch);
      return true;
    }

    // Check for typosquatting
    const typosquattingPatterns = [
      { original: 'google', fake: 'g00gle' },
      { original: 'facebook', fake: 'faceb00k' },
      { original: 'amazon', fake: 'amaz0n' },
      { original: 'paypal', fake: 'paypa1' },
      { original: 'microsoft', fake: 'm1crosoft' },
      { original: 'github', fake: 'g1thub' },
      { original: 'twitter', fake: 'tw1tter' },
      { original: 'instagram', fake: 'insta1gram' },
      { original: 'linkedin', fake: 'link3din' },
      { original: 'youtube', fake: 'youtu1be' },
      { original: 'tiktok', fake: 'tikt0k' },
      { original: 'snapchat', fake: 'snapch4t' },
      { original: 'pinterest', fake: 'pin1ster' },
      { original: 'reddit', fake: 'redd1t' },
      { original: 'ebay', fake: 'ebay1' },
      { original: 'walmart', fake: 'walmart1' },
      { original: 'target', fake: 'targ3t' },
      { original: 'apple', fake: 'appl3' },
      { original: 'microsoft', fake: 'm1crosoft' }
    ];

    for (const pattern of typosquattingPatterns) {
      if (hostname.includes(pattern.fake)) {
        console.log('URL matched typosquatting pattern:', pattern);
        return true;
      }
    }

    // Check against suspicious patterns
    for (const pattern of phishingIndicators.suspiciousPatterns) {
      if (pattern.test(url)) {
        console.log('URL matched suspicious pattern:', pattern);
        return true;
      }
    }

    // Check for suspicious keywords in URL
    for (const keyword of phishingIndicators.keywords) {
      if (url.toLowerCase().includes(keyword)) {
        console.log('URL contains suspicious keyword:', keyword);
        return true;
      }
    }
  } catch (e) {
    console.error('Error parsing URL:', e);
  }
  return false;
}

// Update stats in storage
function updateStats(type, url) {
  chrome.storage.local.get(['stats', 'lastDetection'], function(data) {
    const stats = data.stats || { blocked: 0, warnings: 0, falsePositives: 0 };
    if (type === 'block') {
      stats.blocked = (stats.blocked || 0) + 1;
      // Update last detection
      chrome.storage.local.set({ 
        lastDetection: {
          url: url,
          time: new Date().toISOString(),
          type: 'block'
        }
      });
    } else if (type === 'warning') {
      stats.warnings = (stats.warnings || 0) + 1;
    } else if (type === 'falsePositive') {
      stats.falsePositives = (stats.falsePositives || 0) + 1;
    }
    chrome.storage.local.set({ stats });
  });
}

// Load test links when extension starts
loadTestLinks();

// Listen for messages from content script and popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'CHECK_URL') {
    const isSuspicious = isSuspiciousURL(message.url);
    if (isSuspicious) {
      updateStats('warning', message.url);
    }
    sendResponse({ isSuspicious });
  } else if (message.type === 'REPORT_FALSE_POSITIVE') {
    // Store the reported URL
    chrome.storage.local.get(['reportedUrls'], function(data) {
      const reportedUrls = data.reportedUrls || [];
      if (!reportedUrls.includes(message.url)) {
        reportedUrls.push(message.url);
        chrome.storage.local.set({ reportedUrls });
        updateStats('falsePositive', message.url);
      }
    });
    sendResponse({ success: true });
  } else if (message.type === 'GET_STATS') {
    chrome.storage.local.get(['stats', 'lastDetection'], function(data) {
      sendResponse({
        stats: data.stats || { blocked: 0, warnings: 0, falsePositives: 0 },
        lastDetection: data.lastDetection || null
      });
    });
    return true; // Required for async response
  } else if (message.type === 'BLOCKED_URL') {
    updateStats('block', message.url);
  } else if (message.type === 'GET_STATS_JSON') {
    chrome.storage.local.get(['stats', 'lastDetection'], function(data) {
      sendResponse({
        stats: data.stats || { blocked: 0, warnings: 0, falsePositives: 0 },
        lastDetection: data.lastDetection || null
      });
    });
    return true;
  }
}); 