// Parse the blocked URL from the query string and display it
function getBlockedUrl() {
  const params = new URLSearchParams(window.location.search);
  const url = params.get('url');
  return url ? decodeURIComponent(url) : '';
}

// Determine the link type (dangerous, suspicious, likely) based on the URL
function getLinkType(url) {
  if (!url) return 'likely';
  // Simulate: if contains 'login', 'verify', 'secure', 'bank', etc. => dangerous
  const lower = url.toLowerCase();
  if (lower.includes('login') || lower.includes('verify') || lower.includes('secure') || lower.includes('bank') || lower.includes('phish')) {
    return 'dangerous';
  }
  // If contains 'account', 'update', 'alert', etc. => suspicious
  if (lower.includes('account') || lower.includes('update') || lower.includes('alert')) {
    return 'suspicious';
  }
  // Otherwise, likely
  return 'likely';
}

document.addEventListener('DOMContentLoaded', () => {
  const blockedUrl = getBlockedUrl();
  const linkType = getLinkType(blockedUrl);
  const urlBox = document.getElementById('blockedUrl');
  let boxClass = '';
  let label = '';
  let bodyClass = '';
  let borderClass = '';
  if (linkType === 'dangerous') {
    boxClass = 'danger-url';
    label = 'Dangerous Link';
    bodyClass = 'danger-bg';
    borderClass = 'danger-border';
  } else if (linkType === 'suspicious') {
    boxClass = 'suspicious-url';
    label = 'Suspicious Link';
    bodyClass = 'suspicious-bg';
    borderClass = 'suspicious-border';
  } else {
    boxClass = 'likely-url';
    label = 'Likely Safe Link';
    bodyClass = 'likely-bg';
    borderClass = 'likely-border';
  }
  document.body.classList.add(bodyClass);
  document.querySelector('.blocked-container').classList.add(borderClass);
  urlBox.classList.add(boxClass);
  urlBox.innerHTML = `
    <div class="url-label">Blocked URL:</div>
    <div class="url-value">${blockedUrl ? `<a href="${blockedUrl}" target="_blank" rel="noopener">${blockedUrl}</a>` : 'Unknown'}</div>
    <div class="url-type-label">${label}</div>
  `;

  // Go Back button event listener
  document.getElementById('goBack').addEventListener('click', () => {
    history.back();
  });

  // Optionally, send a message to background to increment the block count
  if (blockedUrl) {
    chrome.runtime.sendMessage({ type: 'BLOCKED_URL', url: blockedUrl });
  }

  // False positive reporting
  document.getElementById('reportFalsePositive').addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'REPORT_FALSE_POSITIVE', url: blockedUrl }, (response) => {
      if (response && response.success) {
        alert('Thank you for your feedback!');
      } else {
        alert('Error reporting. Please try again.');
      }
    });
  });
});

// Listen for real-time stats updates (no longer needed for stats display, but can be kept for future use)
// chrome.storage.onChanged.addListener(function(changes, area) {
//   if (area === 'local' && changes.stats) {
//     updateStatsDisplay();
//   }
// }); 